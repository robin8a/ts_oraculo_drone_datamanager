/**
 * Lambda datadroneuser — POST /users
 * Crea usuario en Cognito, asigna rol/grupo y envía credenciales por SES.
 */

const {
  AdminAddUserToGroupCommand,
  AdminCreateUserCommand,
  AdminGetUserCommand,
  AdminUpdateUserAttributesCommand,
  CognitoIdentityProviderClient,
} = require('@aws-sdk/client-cognito-identity-provider');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');

const cognitoRegion = process.env.COGNITO_REGION || 'us-east-1';
const sesRegion = process.env.SES_REGION || cognitoRegion;

const cognito = new CognitoIdentityProviderClient({ region: cognitoRegion });
const ses = new SESClient({ region: sesRegion });

const USER_POOL_ID = process.env.USER_POOL_ID;
const SES_FROM_EMAIL = process.env.SES_FROM_EMAIL;
const APP_LOGIN_URL = (process.env.APP_LOGIN_URL || '').replace(/\/$/, '');
const APP_NAME = process.env.APP_NAME || 'Terrasacha';

const GROUPS = ['ADMIN', 'SUPERVISOR', 'ANALYST'];

const log = (level, msg, extra) => {
  const line = extra !== undefined ? `${msg} ${JSON.stringify(extra)}` : msg;
  if (level === 'error') {
    console.error(`[datadroneuser] ${line}`);
  } else {
    console.log(`[datadroneuser] ${line}`);
  }
};

const json = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'POST,OPTIONS',
  },
  body: JSON.stringify(body),
});

const formatAwsError = (err, step) => {
  const name = err?.name || err?.Code || 'Error';
  const message = err?.message || String(err);
  log('error', `Fallo en ${step}`, { name, message });
  return { message, errorName: name, step };
};

const parseEventBody = (event) => {
  if (!event.body) {
    return {};
  }
  const raw = event.isBase64Encoded
    ? Buffer.from(event.body, 'base64').toString('utf8')
    : event.body;
  return JSON.parse(raw);
};

const isOptionsRequest = (event) => {
  const method =
    event.requestContext?.http?.method || event.httpMethod || '';
  return method.toUpperCase() === 'OPTIONS';
};

const parseBearer = (event) => {
  const headers = event.headers || {};
  const auth =
    headers.authorization ||
    headers.Authorization ||
    Object.entries(headers).find(([k]) => k.toLowerCase() === 'authorization')?.[1] ||
    '';
  const m = /^Bearer\s+(.+)$/i.exec(auth);
  return m ? m[1] : null;
};

const decodeJwtPayload = (token) => {
  try {
    const part = token.split('.')[1];
    const padded = part.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(Buffer.from(padded, 'base64').toString('utf8'));
  } catch {
    return null;
  }
};

const assertAdmin = (token) => {
  const payload = decodeJwtPayload(token);
  if (!payload) {
    return { ok: false, status: 401, message: 'Token inválido' };
  }
  const groups = payload['cognito:groups'] || [];
  const customRole = payload['custom:role'];
  const isAdmin =
    (Array.isArray(groups) && groups.includes('ADMIN')) || customRole === 'ADMIN';
  if (!isAdmin) {
    return { ok: false, status: 403, message: 'Solo administradores' };
  }
  return { ok: true };
};

const mapUser = (u) => {
  const attrs = {};
  for (const a of u.UserAttributes || u.Attributes || []) {
    attrs[a.Name] = a.Value;
  }
  let projectIds = [];
  try {
    projectIds = JSON.parse(attrs['custom:project_ids'] || '[]');
  } catch {
    projectIds = [];
  }
  return {
    username: u.Username,
    email: attrs.email || '',
    role: attrs['custom:role'] || 'ANALYST',
    supervisorId: attrs['custom:supervisor_id'] || null,
    projectIds,
    enabled: u.Enabled,
    status: u.UserStatus,
  };
};

const ensureGroup = async (username, role) => {
  if (!GROUPS.includes(role)) {
    throw new Error(`Rol inválido: ${role}`);
  }
  await cognito.send(
    new AdminAddUserToGroupCommand({
      UserPoolId: USER_POOL_ID,
      Username: username,
      GroupName: role,
    })
  );
};

const setUserAttributes = async (username, { role, supervisorId, projectIds }) => {
  const attrs = [];
  if (role) {
    attrs.push({ Name: 'custom:role', Value: role });
  }
  if (supervisorId !== undefined) {
    attrs.push({ Name: 'custom:supervisor_id', Value: supervisorId || '' });
  }
  if (projectIds) {
    attrs.push({ Name: 'custom:project_ids', Value: JSON.stringify(projectIds) });
  }
  if (attrs.length === 0) {
    return;
  }
  await cognito.send(
    new AdminUpdateUserAttributesCommand({
      UserPoolId: USER_POOL_ID,
      Username: username,
      UserAttributes: attrs,
    })
  );
};

const sendWelcomeEmail = async ({ email, username, temporaryPassword, role }) => {
  if (!SES_FROM_EMAIL) {
    throw new Error('SES_FROM_EMAIL no configurado');
  }

  const loginHtml = APP_LOGIN_URL
    ? `<p><a href="${APP_LOGIN_URL}">${APP_LOGIN_URL}</a></p>`
    : '';

  await ses.send(
    new SendEmailCommand({
      Source: SES_FROM_EMAIL,
      Destination: { ToAddresses: [email] },
      Message: {
        Subject: { Charset: 'UTF-8', Data: `Acceso a ${APP_NAME}` },
        Body: {
          Html: {
            Charset: 'UTF-8',
            Data: `
              <h2>Bienvenido a ${APP_NAME}</h2>
              <p><b>Usuario:</b> ${username}</p>
              <p><b>Correo:</b> ${email}</p>
              <p><b>Contraseña temporal:</b> ${temporaryPassword}</p>
              <p><b>Rol:</b> ${role}</p>
              ${loginHtml}
              <p>En el primer acceso deberás cambiar la contraseña.</p>
            `,
          },
          Text: {
            Charset: 'UTF-8',
            Data: `Usuario: ${username}\nCorreo: ${email}\nContraseña temporal: ${temporaryPassword}\nRol: ${role}${APP_LOGIN_URL ? `\nURL: ${APP_LOGIN_URL}` : ''}`,
          },
        },
      },
    })
  );
};

const handlePostUsers = async (reqId, body) => {
  const { username, email, temporaryPassword, role, supervisorId, projectIds } = body;

  if (!username || !email || !temporaryPassword || !role) {
    return json(400, { message: 'Faltan campos obligatorios', step: 'validate' });
  }
  if (role === 'ANALYST' && !supervisorId) {
    return json(400, { message: 'Analista requiere supervisorId', step: 'validate' });
  }

  log('info', 'POST /users', { reqId, username, email, role });

  try {
    await cognito.send(
      new AdminCreateUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: username,
        TemporaryPassword: temporaryPassword,
        UserAttributes: [
          { Name: 'email', Value: email },
          { Name: 'email_verified', Value: 'true' },
        ],
        MessageAction: 'SUPPRESS',
      })
    );
  } catch (err) {
    return json(500, formatAwsError(err, 'AdminCreateUser'));
  }

  try {
    await setUserAttributes(username, {
      role,
      supervisorId: role === 'ANALYST' ? supervisorId : '',
      projectIds: projectIds || [],
    });
  } catch (err) {
    return json(500, formatAwsError(err, 'setUserAttributes'));
  }

  try {
    await ensureGroup(username, role);
  } catch (err) {
    return json(500, formatAwsError(err, 'ensureGroup'));
  }

  try {
    await sendWelcomeEmail({ email, username, temporaryPassword, role });
  } catch (err) {
    return json(500, {
      ...formatAwsError(err, 'sendWelcomeEmail'),
      hint: 'Verifica SES (remitente y destino en sandbox).',
    });
  }

  try {
    const got = await cognito.send(
      new AdminGetUserCommand({
        UserPoolId: USER_POOL_ID,
        Username: username,
      })
    );
    return json(201, { ...mapUser(got), emailSent: true });
  } catch (err) {
    return json(500, formatAwsError(err, 'AdminGetUser'));
  }
};

exports.handler = async (event) => {
  const reqId = event.requestContext?.requestId || 'unknown';

  try {
    log('info', 'Invocación', {
      reqId,
      method: event.requestContext?.http?.method || event.httpMethod,
      path: event.path || event.rawPath,
      USER_POOL_ID: USER_POOL_ID ? 'ok' : 'FALTA',
      SES_FROM_EMAIL: SES_FROM_EMAIL ? 'ok' : 'FALTA',
    });

    if (isOptionsRequest(event)) {
      return {
        statusCode: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,Authorization',
          'Access-Control-Allow-Methods': 'POST,OPTIONS',
        },
        body: '',
      };
    }

    if (!USER_POOL_ID) {
      return json(500, { message: 'USER_POOL_ID no configurado', step: 'config' });
    }

    const token = parseBearer(event);
    if (!token) {
      return json(401, { message: 'Authorization Bearer requerido', step: 'auth' });
    }

    const auth = assertAdmin(token);
    if (!auth.ok) {
      return json(auth.status, { message: auth.message, step: 'auth' });
    }

    const method = (
      event.httpMethod ||
      event.requestContext?.http?.method ||
      ''
    ).toUpperCase();
    const path = event.path || event.rawPath || '';

    if (method !== 'POST' || !(path.endsWith('/users') || path === '/users')) {
      return json(404, { message: 'Solo POST /users', step: 'route' });
    }

    let body;
    try {
      body = parseEventBody(event);
    } catch {
      return json(400, { message: 'JSON inválido', step: 'parseBody' });
    }

    return await handlePostUsers(reqId, body);
  } catch (err) {
    log('error', 'Handler crash', {
      reqId,
      name: err?.name,
      message: err?.message,
      stack: err?.stack,
    });
    return json(500, {
      message: err?.message || 'Error interno',
      errorName: err?.name || 'UnhandledError',
      step: 'handler',
    });
  }
};
